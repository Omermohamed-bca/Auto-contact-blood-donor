# #ONE for finding Donners
##----------------------------------------------------------------------##
# from ONE_Finding_donners_screen import Finding_blood_tkscreen
# v = Finding_blood_tkscreen()

#
# #TWO for thanking those who and all gave blood
##---------------------------------------------------------------------------##
# from TWO_blood_donated_doners_screen import updating_the_date_of_blood_given_donners_tkscreen
# f=updating_the_date_of_blood_given_donners_tkscreen()
#

# #THREE for new donners Registration
##---------------------------------------------------------------------------##
# from THREE_donners_registration_portal_screen import donners_registration_tkscreen
# h = donners_registration_tkscreen()


# #FOUR Status update
##---------------------------------------------------------------------------##
# from FOUR_status_update_screen import status_update_tkscreen
# l=status_update_tkscreen()

from main_screen_of_auto_contact_blood_doners import tkscreen
tkscreen()
